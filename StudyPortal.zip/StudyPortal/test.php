<?php
/**
 * Created by PhpStorm.
 * User: Lenovo
 * Date: 28/10/2016
 * Time: 07:53 PM
 */
echo "tai naki?";

?>